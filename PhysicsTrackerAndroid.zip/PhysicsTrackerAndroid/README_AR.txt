مشروع Android لتغليف ملف HTML داخل تطبيق WebView.

لإنشاء APK:
1) افتح المجلد في Android Studio (Open).
2) انتظر Gradle Sync.
3) من القائمة Build اختر Build APK(s).
4) ملف APK يظهر عادة في app/build/outputs/apk/debug/app-debug.apk

ملاحظات:
- صفحة HTML الأصلية محفوظة داخل app/src/main/assets/index.html.
- يتم تشغيل JavaScript وDOM Storage داخل WebView.
- مزامنة Google Sheets تحتاج اتصال إنترنت.
- اختبر النسخ الاحتياطي والطباعة/التصدير على جهاز Android بعد البناء.
